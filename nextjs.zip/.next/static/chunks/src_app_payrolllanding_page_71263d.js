(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_payrolllanding_page_71263d.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_payrolllanding_page_71263d.js",
  "chunks": [
    "static/chunks/node_modules_f530fc._.js",
    "static/chunks/src_app_payrolllanding_page_d163ee.js",
    "static/chunks/node_modules_swiper_41b7b2._.css"
  ],
  "source": "dynamic"
});
