(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_todolanding_page_71263d.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_todolanding_page_71263d.js",
  "chunks": [
    "static/chunks/node_modules_0cb151._.js",
    "static/chunks/src_app_todolanding_page_cdf5e2.js",
    "static/chunks/node_modules_swiper_acd668._.css"
  ],
  "source": "dynamic"
});
