(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_71263d.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_71263d.js",
  "chunks": [
    "static/chunks/node_modules_next_0766a2._.js",
    "static/chunks/node_modules_swiper_a79a56._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_react-paginate_dist_react-paginate_1e509d.js",
    "static/chunks/src_app_page_068932.js",
    "static/chunks/node_modules_swiper_41b7b2._.css"
  ],
  "source": "dynamic"
});
